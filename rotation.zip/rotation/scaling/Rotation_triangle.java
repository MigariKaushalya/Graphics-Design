import javax.swing.*;
import java.awt.*;

public class Rotation_rectangle1 extends JFrame
{
	public Rotation_rectangle1()
	{
		setTitle("Rectangle_Rotation_45_Degree");
		setSize(600,600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	
	public void paint(Graphics g)
	{
		super.paint(g);
		
		// Define the 4 vertices of the rectangle in clockwise order
		int x1 = 100, y1 = 100; // Top-Left
		int x2 = 300, y2 = 100; // Top-Right
		int x3 = 300, y3 = 200; // Bottom-Right
		int x4 = 100, y4 = 200; // Bottom-Left
		
		// Draw original rectangle in BLUE
		g.setColor(Color.BLUE);
		draw_Rectangle(g, x1, y1, x2, y2, x3, y3, x4, y4);
		
		// Calculate precise center using floating-point division (4.0)
		double cx = (x1 + x2 + x3 + x4) / 4.0;
		double cy = (y1 + y2 + y3) / 4.0;
		
		// Mark the rotation pivot point in BLACK
		g.setColor(Color.BLACK);
		g.fillRect((int)Math.round(cx), (int)Math.round(cy), 3, 3);
		
		// Define rotation angle in radians
		double theta = Math.toRadians(45);
		double cosTheta = Math.cos(theta);
		double sinTheta = Math.sin(theta);
		
		// Fixed point rotation formula applied to all 4 vertices:
		// X_new = cx + (x - cx) * cos(theta) - (y - cy) * sin(theta)
		// Y_new = cy + (x - cx) * sin(theta) + (y - cy) * cos(theta)
		int rx1 = (int) Math.round(cx + (x1 - cx) * cosTheta - (y1 - cy) * sinTheta);
		int ry1 = (int) Math.round(cy + (x1 - cx) * sinTheta + (y1 - cy) * cosTheta);
		
		int rx2 = (int) Math.round(cx + (x2 - cx) * cosTheta - (y2 - cy) * sinTheta);
		int ry2 = (int) Math.round(cy + (x2 - cx) * sinTheta + (y2 - cy) * cosTheta);
		
		int rx3 = (int) Math.round(cx + (x3 - cx) * cosTheta - (y3 - cy) * sinTheta);
		int ry3 = (int) Math.round(cy + (x3 - cx) * sinTheta + (y3 - cy) * cosTheta);
		
		int rx4 = (int) Math.round(cx + (x4 - cx) * cosTheta - (y4 - cy) * sinTheta);
		int ry4 = (int) Math.round(cy + (x4 - cx) * sinTheta + (y4 - cy) * cosTheta);
		
		// Draw 45-degree rotated rectangle in RED
		g.setColor(Color.RED);
		draw_Rectangle(g, rx1, ry1, rx2, ry2, rx3, ry3, rx4, ry4);
	}
	
	// Helper method to draw a 4-sided polygon using DDA
	public void draw_Rectangle(Graphics g, int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4)
	{
		draw_DDA(g, x1, y1, x2, y2); // Edge 1: Top
		draw_DDA(g, x2, y2, x3, y3); // Edge 2: Right
		draw_DDA(g, x3, y3, x4, y4); // Edge 3: Bottom
		draw_DDA(g, x4, y4, x1, y1); // Edge 4: Left
	}
	
	public void draw_DDA(Graphics g, int x1, int y1, int x2, int y2)
	{
		int dx = x2 - x1;
		int dy = y2 - y1;
		
		int steps;
		if(Math.abs(dx) < Math.abs(dy))
		{
			steps = Math.abs(dy);
		}
		else
		{
			steps = Math.abs(dx);
		}
		
		float incX = dx / (float)steps;
		float incY = dy / (float)steps;
		
		float x = x1;
		float y = y1;
		
		for(int i = 0; i <= steps; i++)
		{
			g.fillRect(Math.round(x), Math.round(y), 1, 1);
			x = x + incX;
			y = y + incY;
		}
	}
	
	public static void main(String args[])
	{
		new Rotation_rectangle1();
	}
}
