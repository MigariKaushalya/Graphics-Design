import javax.swing.*;
import java.awt.*;

public class Scaling_triangle extends JFrame
{
	public Scaling_triangle()
	{
		setTitle("Scaling_02");
		setSize(600,600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	
	public void paint(Graphics g)
	{
		super.paint(g);
		
		
		int x1 = 150, y1 = 100;
		int x2 = 50,  y2 = 50;
		int x3 = 200, y3 = 50;
		
		// Draw original triangle in BLUE
		g.setColor(Color.BLUE);
		draw_Triangle(g, x1, y1, x2, y2, x3, y3);
		
		
		int cx = (x1 + x2 + x3) / 3;
		int cy = (y1 + y2 + y3) / 3;
		
		
		g.setColor(Color.BLACK);
		g.fillRect(cx, cy, 2, 2);
		
		// Scaling factor (2x size)
		double sx = 1.5;
		double sy = 1.5;
		
		// Fixed point scaling formula: X_new = Cx + (X - Cx) * Sx
		int sx1 = (int) Math.round(cx + (x1 - cx) * sx);
		int sy1 = (int) Math.round(cy + (y1 - cy) * sy);
		int sx2 = (int) Math.round(cx + (x2 - cx) * sx);
		int sy2 = (int) Math.round(cy + (y2 - cy) * sy);
		int sx3 = (int) Math.round(cx + (x3 - cx) * sx);
		int sy3 = (int) Math.round(cy + (y3 - cy) * sy);
		
		// Draw scaled triangle in RED
		g.setColor(Color.RED);
		draw_Triangle(g, sx1, sy1, sx2, sy2, sx3, sy3);
	}
	
	
	public void draw_Triangle(Graphics g, int x1, int y1, int x2, int y2, int x3, int y3)
	{
		draw_DDA(g, x1, y1, x2, y2); 
		draw_DDA(g, x2, y2, x3, y3); 
		draw_DDA(g, x3, y3, x1, y1); 
	}
	
	public void draw_DDA(Graphics g,int x1,int y1,int x2,int y2)
	{
		int dx = x2-x1;
		int dy = y2-y1;
		
		int steps;
		
		if(Math.abs(dx) < Math.abs(dy))
		{
			steps=Math.abs(dy);
		}
		else
		{
			steps=Math.abs(dx);
		}
		
		float incX = dx/(float)steps;
		float incY = dy/(float)steps;
		
		float x = x1;
		float y = y1;
		
		for(int i=0; i<=steps; i++)
		{
			g.fillRect(Math.round(x),Math.round(y),1,1);
			x = x+incX;
			y = y+incY;
		}
	}
	
	public static void main(String args[])
	{
		new Scaling_triangle();
	}
}
