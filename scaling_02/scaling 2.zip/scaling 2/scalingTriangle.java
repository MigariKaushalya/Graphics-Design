import javax.swing.*;
import java.awt.*;

public class scalingTriangle extends JFrame
{
	public scalingTriangle()
	{
		setTitle("Scaling_02");
		setSize(600,600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	public void paint(Graphics g)
	{
		super.paint(g);
		
		//Graphics2D g2 =(Graphics2D)g;
		//g2.setStroke(new BasicStroke(7)) ;
		
		g.setFont(new Font("arial",Font.BOLD,40));
		g.drawString("scaling",150,60);
		
		int x[]={100,200,300,};
		int y[]={300,100,300,};
		
		for(int i=0; i<x.length; i++)
		{
			g.setColor(Color.green);
			draw_DDA(g,x[i],y[i],x[(i+1)%x.length],y[(i+1)%y.length]);
		}
		
		double sx=1.5,sy =1.5;
		
		for(int i=0; i<x.length; i++)
		{
			g.setColor(Color.red);
			int scaledX1 = (int) Math.round(x[i] * sx);
			int scaledY1 = (int) Math.round(y[i] * sy);
			int scaledX2 = (int) Math.round(x[(i+1)%x.length] * sx);
			int scaledY2 = (int) Math.round(y[(i+1)%y.length] * sy);
			
			draw_DDA(g, scaledX1, scaledY1, scaledX2, scaledY2);
		}
		
	}
	public void draw_DDA(Graphics g,int x1,int y1,int x2,int y2)
	{
		int dx = x2-x1;
		int dy =y2-y1;
		
		int steps;
		
		if(Math.abs(dx) < Math.abs(dy))
		{
			steps=Math.abs(dy);
		}
		else
		{
			steps=Math.abs(dx);
		}
		
		float incX = dx/(float)steps;
		float incY =dy/(float)steps;
		
		float x =x1;
		float y =y1;
		
		for(int i=0; i<steps; i++)
		{
			g.fillRect(Math.round(x),Math.round(y),1,1);
			x =x+incX;
			y =y+incY;
		}
	}
	
	public static void main(String args[])
	{
		new scalingTriangle();
	}

}