import javax.swing.*;
import java.awt.*;

public class scalingRect extends JFrame{
	private int xpoints[] ={100,200,200,100};
	private int ypoints[] ={100,100,200,200};
	
	public scalingRect()
	{
		setTitle("scalingRect");
		setSize(600,600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public void paint(Graphics g)
	{
		super.paint(g);
		
		//originalrectangle
		g.setColor(Color.blue);
		drawRectangle(g,xpoints,ypoints);
		
		//scaled rectangle
		
		int[][] scaled = scale(xpoints,ypoints,2,2);//scaled by 2 factors
		g.setColor(Color.red);
		drawRectangle(g,scaled[0],scaled[1]);
	}
	
	private void drawRectangle (Graphics g,int x[],int y[])
	{
		drawDDA(g,x[0],y[0],x[1],y[1]);
		drawDDA(g,x[1],y[1],x[2],y[2]);
		drawDDA(g,x[2],y[2],x[3],y[3]);
		drawDDA(g,x[3],y[3],x[0],y[0]);
	}
	
	private int[][] scale (int x[],int y[],double sx,double sy)
	{
		int newx[] = new int [x.length];
		int newy[] =new int [y.length];
		
		for(int i=0; i<x.length; i++)
		{
			newx[i] = (int) (x[i]*sx);
			newy[i] = (int) (y[i]*sy);
		}
		
		return new int[][] {newx,newy};
	}
	
	public void drawDDA(Graphics g,int x1,int y1,int x2,int y2)
	{
		int dx = x2-x1;
		int dy =y2-y1;
		
		int steps;
		
		if(Math.abs(dx) < Math.abs(dy))
		{
			steps=Math.abs(dy);
		}
		else
		{
			steps=Math.abs(dx);
		}
		
		float incX = dx/(float)steps;
		float incY =dy/(float)steps;
		
		float x =x1;
		float y =y1;
		
		for(int i=0; i<steps; i++)
		{
			g.fillRect(Math.round(x),Math.round(y),1,1);
			x =x+incX;
			y =y+incY;
		}
	
	}
	public static void main(String args[])
	{
		new scalingRect();
	}
}