import javax.swing.*;
import java.awt.*;

public class Scaling_circle extends JFrame
{
	public Scaling_circle()
	{
		setTitle("Scaling_02");
		setSize(1000,1000);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	public void paint(Graphics g)
	{
		super.paint(g);
		
		//Graphics2D g2 =(Graphics2D)g;
		//g2.setStroke(new BasicStroke(7)) ;
		
		g.setFont(new Font("arial",Font.BOLD,40));
		g.drawString("scaling",150,60);
		
		int xc=300,yc=300,r=100;
		g.setColor(Color.green);
		bresenhamCircle(g,xc,yc,r);
		
		int sx=2,sy=2;
		g.setColor(Color.red);
		bresenhamCircle(g,xc,yc,r*2);
		
		
		
	}
	
	public void bresenhamCircle(Graphics g,int xc,int yc, int r )
	{
		int x=0;
		int y=r;
		int d=3-2*r;
		while(x<y)
		{
			
			g.fillOval(xc+x,yc+y,2,2);
		    g.fillOval(xc-x,yc+y,2,2);
			g.fillOval(xc+x,yc-y,2,2);
			g.fillOval(xc-x,yc-y,2,2);
			
			
			g.fillOval(xc+y,yc+x,2,2);
			g.fillOval(xc-y,yc+x,2,2);
			g.fillOval(xc+y,yc-x,2,2);
			g.fillOval(xc-y,yc-x,2,2);
			
			if(d<0)
			{
				d+=4*x+6;
				x++;
			}
			else
			{
				d+=4*(x-y)+10;
				x++;
				y--;
			}
			
			
		}
		
	}
	
	public static void main(String args[])
	{
		new Scaling_circle();
	}
}